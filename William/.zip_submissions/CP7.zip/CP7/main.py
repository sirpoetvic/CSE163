import os
import tempfile
os.environ["MPLCONFIGDIR"] = tempfile.gettempdir()

import geopandas as gpd
import matplotlib.pyplot as plt


def create_south_america_png():
    all_countries = gpd.read_file('geo_data/ne_110m_admin_0_countries.shp')

    south_america = all_countries[
        all_countries['CONTINENT'] == 'South America']

    fig, ax = plt.subplots(1)
    south_america.plot(ax=ax,
                       column='POP_EST',
                       legend=True)

    # plt.show()
    plt.savefig('south_america.png')


def create_small_and_rich_png():
    # Your code goes here!
    all_countries = gpd.read_file('geo_data/ne_110m_admin_0_countries.shp')

    # filters for rich & small
    is_rich = all_countries['GDP_MD_EST'] >= 500000
    is_small = all_countries['POP_EST'] <= 80000000

    all_together = all_countries[is_rich & is_small]

    fig, ax = plt.subplots(1, figsize=(15, 7))

    # plot the grey bg
    all_countries.plot(ax=ax,
                       color="#EEEEEE")

    # plot the filtered data ontop of the same plot
    all_together.plot(ax=ax,
                      column='GDP_MD_EST',
                      legend=True)
    # plt.show()
    plt.savefig('small_and_rich.png')


def create_populations_png():
    all_countries = gpd.read_file('geo_data/ne_110m_admin_0_countries.shp')

    fig, [ax1, ax2, ax3] = plt.subplots(3)

    # top plot
    all_countries.plot(ax=ax1,
                       column="POP_EST",
                       legend=True)

    # middle plot
    sub_region = all_countries.dissolve(by='SUBREGION', aggfunc='sum')
    sub_region.plot(ax=ax2,
                    column='POP_EST',
                    legend=True)

    # bottom plot
    continent = all_countries.dissolve(by='CONTINENT', aggfunc='sum')
    continent.plot(ax=ax3,
                   column='POP_EST',
                   legend=True)

    # plt.show()
    plt.savefig("populations.png")


def main():
    create_south_america_png()
    create_small_and_rich_png()
    create_populations_png()


if __name__ == '__main__':
    main()
